<?php echo e($slot); ?>

<?php /**PATH /Users/jasmin/Documents/work/websites/ujatcare/api/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>